DROP DATABASE IF EXISTS servidor;

CREATE DATABASE servidor DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

USE servidor;

DROP USER IF EXISTS 'superadm'@'localhost';

CREATE USER 'superadm'@'localhost' IDENTIFIED BY '160799';

GRANT SELECT, INSERT, UPDATE, DELETE ON servidor.* TO 'superadm'@'localhost';


CREATE TABLE player(
    dtfirstlogin DATE,
    nick VARCHAR(50) not null,
    steamid VARCHAR(50) PRIMARY KEY,
    email VARCHAR(50) not null,
    nomereal VARCHAR(50),
    idade INTEGER,
    senha VARCHAR(50) not null
);

CREATE TABLE inscricao(
    numero INTEGER AUTO_INCREMENT PRIMARY KEY,
    steamid VARCHAR(50),
    exp INTEGER,
    descexp VARCHAR(50), 
    commend INTEGER,
    nomecommend VARCHAR(50),     
    hrsdejogo VARCHAR(50) not null,
    motivo TEXT not null,
    aprovado INTEGER,
    foreign key (steamid) references player (steamid)
);

CREATE TABLE staff(
    steamid VARCHAR(50) PRIMARY KEY,
    cargo INTEGER not null,
    estado INTEGER not null,
    dtingresso DATE not null,    
    foreign key (steamid) references player (steamid)    
 );

CREATE TABLE cargo (
    descr VARCHAR(50) not null,
    id INTEGER PRIMARY KEY
);

CREATE TABLE estado (
    descr VARCHAR(50) not null,
    id INTEGER PRIMARY KEY
);

CREATE TABLE avalia (
    numero INTEGER AUTO_INCREMENT PRIMARY KEY,
    steamid_player VARCHAR(50) not null,
    steamid_staff VARCHAR(50) not null,
    nota FLOAT not null,
    tipo INTEGER not null,
    coment TEXT not null
);

CREATE TABLE tipo(
    descr VARCHAR(50) not null,
    id INTEGER PRIMARY KEY
);

CREATE TABLE coment(
    dthora DATETIME PRIMARY KEY,
    player_steamid VARCHAR(50),
    texto TEXT,
    post_dthora DATETIME
);

CREATE TABLE post(
    dthora DATETIME PRIMARY KEY,
    texto TEXT NOT NULL,
    player_steamid VARCHAR(50),
    foreign key (player_steamid) references player (steamid)
);

CREATE TABLE bane(
    numero INTEGER AUTO_INCREMENT PRIMARY KEY,
    player_steamid VARCHAR(50) not null,
    staff_steamid VARCHAR(50) not null,
    duracao TIME not null,
    motivo TEXT not null,
    justifi TEXT not null,
    foreign key (player_steamid) references player (steamid),
    foreign key (staff_steamid) references player (steamid) 
);

CREATE TABLE curtida_coment(
    numero INTEGER AUTO_INCREMENT PRIMARY KEY,
    player_steamid VARCHAR(50),
    coment_dthora DATETIME,
    foreign key (player_steamid) references player (steamid),
    foreign key (coment_dthora) references coment (dthora)
);

CREATE TABLE curtida_post(
    numero INTEGER AUTO_INCREMENT PRIMARY KEY,
    player_steamid VARCHAR(50),
    post_dthora DATETIME,
    foreign key (player_steamid) references player (steamid),
    foreign key (post_dthora) references post (dthora)
);


ALTER TABLE avalia ADD CONSTRAINT FK_avalia_1
    foreign key (tipo) 
    references tipo (id);

ALTER TABLE avalia ADD CONSTRAINT FK_avalia_2
    foreign key (steamid_staff) 
    references player (steamid);

ALTER TABLE avalia ADD CONSTRAINT FK_avalia_3
    foreign key (steamid_player) 
    references player (steamid);

ALTER TABLE coment ADD CONSTRAINT FK_coment_1
    foreign key (player_steamid) 
    references player(steamid);

ALTER TABLE coment ADD CONSTRAINT FK_coment_2 
    foreign key (dthora) 
    references post(dthora);

ALTER TABLE staff ADD CONSTRAINT FK_staff_1
    foreign key (cargo) 
    references cargo (id);
ALTER TABLE staff ADD CONSTRAINT FK_staff_2
    foreign key (estado) 
    references estado (id);


INSERT INTO cargo(descr, id) values ("Helper", 1),("Moderador", 2),("Administrador", 3),("Administrador Chefe", 4),("Super Administrador", 5),("Dono",6);
INSERT INTO estado (descr, id) VALUES ("Ativo", 1),("Afastado / Ausente", 2), ("Desligado", 3);
INSERT INTO tipo(descr, id) VALUES ("Crítica", 1), ("Denúncia", 2), ("Elogio", 3), ("Valiação", 4);
