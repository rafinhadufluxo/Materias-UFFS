<!DOCTYPE html>
<?php
include: "conexao.php";
$erros=array();
	# se o botao de cadastro foi clicado
	if(isset($_POST['Confirmar'])){
		$nome = trim(addslashes($_POST['nome']));
		$genero = $_POST['genero'];
		$Encerrada = isset($_POST['Encerrada']) ? 1 : 0;
		$texto = isset($_Post['texto']);
		$avaliacao = isset($_Post['avaliacao']);
		// Validações
		if (empty($nome) || !strstr($nome," "))
			$erros[] = "Digite seu nome completo";

       	if(empty($avaliacao))
      		$erros[] = "Seleicone um valor";  

       	if(empty($genero))
       		$erros[] = "Selecione um genero";

       	if(empty($texto))
			$erros[] = "Digite o comentário";

		$date = date("Y-m-D");

		if (count($erros) == 0) {
			echo $sql = "INSERT INTO reviews(nomeSerie, codGenero, avaliacao, texto, encerrada, data, curtidas) values ($nome, $genero, $avaliacao, $texto, $Encerrada,$date ,0)";
		}
	}
?>
<html lang="pt-br">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="utf-8">
	<title>Rent a Tool</title>
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet"> <!-- web font Lobster -->
</head>

<body>
	<!-- cabeçalho -->
	<header>		
	</header>
	<!-- fim cabeçalho -->

	<!-- area central com 3 colunas -->
	<div class="container">
		<h2>Review</h2>
			<div>
				<form action="cliente.php" method="post" id="form-contato">
				    <div class="form-item">
				      <label for="nome" class="label-alinhado">Nome da Série:</label>
				      <input type="text" id="nome" name="nome" size="50" placeholder="Nome da Serie">
				      <span class="msg-erro" id="msg-nome"></span>
				    </div>

				    <div class="form-item">
				      <label for="genero" class="label-alinhado">Genero:</label>
				      <select name="genero" id="genero">
					    <option value="">Selecione</option>
					    <option>
					    	<?php					    	
								if (isset($_POST['nomeGenero']))
									foreach($_POST['nomeGenero'] as $genero) 						
							?>		    	
					    </option>				    
					  </select>
					  <span class="msg-erro" id="msg-genero"></span>
				    </div>

				    <div class="form-item">
				      <label class="label-alinhado">Avaliação:</label>
				      <label><input type="radio" name="n0" value="0" id="avaliacao">0</label>
				      <label><input type="radio" name="n1" value="1" id="avaliacao">1</label>
				      <label><input type="radio" name="n2" value="2" id="avaliacao">2</label>
				      <label><input type="radio" name="n3" value="3" id="avaliacao">3</label>
				      <label><input type="radio" name="n4" value="4" id="avaliacao">4</label>
				      <label><input type="radio" name="n5" value="5" id="avaliacao">5</label> 
					  <span class="msg-erro" id="msg-perfil"></span>
				    </div>

				    <div class="form-item">
				    	<label class="label-alinhado"></label>
				    <textarea name="texto" rows="5" cols = "20" placeholder="Texto"></textarea>
				    </div>

				    <div class="form-item">
				      <label class="label-alinhado"></label>
				      <label><input type="checkbox" id="encerrada" name="encerrada">Encerrada</label>
				      <span class="msg-erro" id="msg-concordo"></span>
				    </div>	


				    <div class="form-item">
				    	<label class="label-alinhado"></label>
				    <input type="submit" id="confirmar" value="Confirmar">
				    </div>

				     <div class="form-item">
				    	<label class="label-alinhado"></label>
				    <input type="submit" id="limpar" value="Limpar">
				    </div>
				    
				    
				</form>
			</div>		
	</div>
	<!-- fim area central -->
	<!-- rodape -->
	<footer>		
	</footer>
	<!-- fim rodape -->

</body>
</html>